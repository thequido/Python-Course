#Code for new module below
def area_of_rectangle(l,w):
    """
    This function returns the area of a rectangle
    """
    return l * w

def area_of_circle(r):
    """
    This function returns the area of a circle
    """
    return 3.1415 * (r ** 2)
